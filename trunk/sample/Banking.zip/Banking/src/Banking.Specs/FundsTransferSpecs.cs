﻿using System;
using NUnit.Framework;
using SpecUnit;

namespace Banking.Specs
{
	[Concern("Funds transfer")]
	public class when_transferring_between_two_accounts
		: behaves_like_context_with_from_account_and_to_account
	{
		protected override void Because()
		{
			_fromAccount.Transfer(1m, _toAccount);
		}

		[Observation]
		public void should_debit_the_from_account_by_the_amount_transferred()
		{
			_fromAccount.Balance.ShouldEqual(0m);
		}

		[Observation]
		public void should_credit_the_to_account_by_the_amount_transferred()
		{
			_toAccount.Balance.ShouldEqual(2m);
		}
	}

	[Concern("Funds transfer")]
	public class when_transfering_an_amount_greater_than_the_balance_of_the_from_account
		: behaves_like_context_with_from_account_and_to_account
	{
		private Exception _exception;

		protected override void Because()
		{
			_exception = ((MethodThatThrows) delegate
			{
				_fromAccount.Transfer(2m, _toAccount);
			})
			.GetException();
		}

		[Observation]
		public void should_not_allow_the_transfer()
		{
			_exception.ShouldNotBeNull();
		}

		[Observation]
		public void should_raise_System_Exception()
		{
			_exception.ShouldBeOfType(typeof(Exception));
		}
	}

	[TestFixture]
	[Concern("Funds transfer")]
	public abstract class behaves_like_context_with_from_account_and_to_account : ContextSpecification
	{
		protected Account _fromAccount;
		protected Account _toAccount;

		protected override void Context()
		{
			_fromAccount = new Account { Balance = 1m };
			_toAccount = new Account { Balance = 1m };
		}
	}
}